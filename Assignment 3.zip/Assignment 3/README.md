required: Godot downloaded on system

In order to run project open "Assignment 3" using Godot
After opening click "Run Project" in top corner or press "Command + B"
